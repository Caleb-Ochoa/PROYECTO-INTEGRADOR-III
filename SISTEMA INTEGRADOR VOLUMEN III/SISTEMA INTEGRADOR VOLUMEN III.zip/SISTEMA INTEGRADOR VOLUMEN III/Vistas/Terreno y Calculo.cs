﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SISTEMA_INTEGRADOR_VOLUMEN_III.Vistas
{
    public partial class Terreno_y_Calculo : Form
    {
        public Terreno_y_Calculo()
        {
            InitializeComponent();
        }
    }
}
