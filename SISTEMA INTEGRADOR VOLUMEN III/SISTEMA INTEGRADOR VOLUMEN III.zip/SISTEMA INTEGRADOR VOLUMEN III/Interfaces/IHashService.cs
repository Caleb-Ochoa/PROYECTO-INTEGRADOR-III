﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SISTEMA_INTEGRADOR_VOLUMEN_III.Interfaces
{
    internal interface IHashService
    {
        string Hash(string textoPlano);
        bool Verify(string textoPlano, string hashGuardado);
    }
}
